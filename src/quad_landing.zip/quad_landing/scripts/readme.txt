1. First the takeoff command.
2. `odom.py` is required to get the position of the platform.
3. `position.py` is required to make the drone hover over the platform.
4. Finally `cameraDownChecker2.py` to land the drone over the platform.
